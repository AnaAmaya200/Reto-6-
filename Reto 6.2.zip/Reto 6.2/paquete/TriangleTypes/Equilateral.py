import math
from paquete.Line import Line
from paquete.Triangle import Triangle
from paquete.Point import Point

class Equilateral(Triangle):
    def __init__(self, Bottom_left_corner: Point, Bottom_right_corner: Point, Upper_corner: Point):
        try:
            if not all(isinstance(vertex, Point) for vertex in [Bottom_left_corner, Bottom_right_corner, Upper_corner]):
                raise TypeError("Todos los vértices deben ser instancias de la clase Point.")
            super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)
            self.is_regular = True
        except TypeError as te:
            print(f"Error de tipo: {te}")
        except Exception as e:
            print(f"Error al inicializar el triángulo equilátero: {e}")

    def compute_area(self):
        try:
            return (((self.edges[0].compute_length())**2) * math.sqrt(3)) / 4
        except Exception as e:
            raise RuntimeError(f"Error al calcular el área del triángulo equilátero: {e}")

    def compute_perimeter(self):
        try:
            return super().compute_perimeter()
        except Exception as e:
            raise RuntimeError(f"Error al calcular el perímetro del triángulo equilátero: {e}")

    def compute_inner_angles(self):
        try:
            self.inner_angles = [60] * 3
            return self.inner_angles
        except Exception as e:
            raise RuntimeError(f"Error al calcular los ángulos internos del triángulo equilátero: {e}")
