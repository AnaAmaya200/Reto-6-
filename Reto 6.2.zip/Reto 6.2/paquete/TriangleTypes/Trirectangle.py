import math
from paquete.Line import Line
from paquete.Triangle import Triangle
from paquete.Point import Point

class Trirectangle(Triangle):
    def __init__(self, Bottom_left_corner: Point, Bottom_right_corner: Point, Upper_corner: Point):
        try:
            if not all(isinstance(vertex, Point) for vertex in [Bottom_left_corner, Bottom_right_corner, Upper_corner]):
                raise TypeError("Todos los vértices deben ser instancias de la clase Point.")
            super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)
        except TypeError as te:
            print(f"Error de tipo: {te}")
        except Exception as e:
            print(f"Error al inicializar el triángulo rectángulo: {e}")

    def compute_perimeter(self):
        try:
            return super().compute_perimeter()
        except Exception as e:
            raise RuntimeError(f"Error al calcular el perímetro del triángulo rectángulo: {e}")
  
    def compute_area(self):
        try:
            if self.vertices[1].y == self.vertices[2].y:
                return (self.edges[0].compute_length() * self.edges[1].compute_length()) / 2
            else:
                return (self.edges[0].compute_length() * self.edges[2].compute_length()) / 2
        except Exception as e:
            raise RuntimeError(f"Error al calcular el área del triángulo rectángulo: {e}")
    
    def compute_inner_angles(self):
        try:
            a = 90
            if self.vertices[1].y == self.vertices[2].y:
                b = math.degrees(math.atan(self.edges[1].compute_length() / self.edges[0].compute_length()))
            else:
                b = math.degrees(math.atan(self.edges[2].compute_length() / self.edges[0].compute_length()))
            c = a - b
            self.inner_angles = [a, b, c]
            return self.inner_angles
        except Exception as e:
            raise RuntimeError(f"Error al calcular los ángulos internos del triángulo rectángulo: {e}")

