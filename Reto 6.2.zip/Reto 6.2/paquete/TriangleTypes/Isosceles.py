import math
from paquete.Line import Line
from paquete.Triangle import Triangle
from paquete.Point import Point

class Isosceles(Triangle):
    def __init__(self, Bottom_left_corner: Point, Bottom_right_corner: Point, Upper_corner: Point):
        try:
            if not all(isinstance(vertex, Point) for vertex in [Bottom_left_corner, Bottom_right_corner, Upper_corner]):
                raise TypeError("Todos los vértices deben ser instancias de la clase Point.")
            super().__init__(Bottom_left_corner, Bottom_right_corner, Upper_corner)
        except TypeError as te:
            print(f"Error de tipo: {te}")
        except Exception as e:
            print(f"Error al inicializar el triángulo isósceles: {e}")

    def compute_area(self):
        try:
            h = ((self.edges[1].compute_length())**2 + (self.edges[0].compute_length())**2)**0.5
            return (self.edges[0].compute_length() * h) / 2
        except Exception as e:
            raise RuntimeError(f"Error al calcular el área del triángulo isósceles: {e}")
  
    def compute_perimeter(self):
        try:
            return super().compute_perimeter()
        except Exception as e:
            raise RuntimeError(f"Error al calcular el perímetro del triángulo isósceles: {e}")

    def compute_inner_angles(self):
        try:
            A = math.degrees(math.acos(((self.edges[1].compute_length())**2 + (self.edges[2].compute_length())**2 - (self.edges[0].compute_length())**2) / (2 * (self.edges[1].compute_length()) * (self.edges[2].compute_length()))))
            B = math.degrees(math.acos(((self.edges[0].compute_length())**2 + (self.edges[2].compute_length())**2 - (self.edges[1].compute_length())**2) / (2 * (self.edges[0].compute_length()) * (self.edges[2].compute_length()))))
            C = 180 - A - B

            self.inner_angles = [A, B, C]
            return self.inner_angles
        except Exception as e:
            raise RuntimeError(f"Error al calcular los ángulos internos del triángulo isósceles: {e}")

