from paquete.Point import Point

class Line:
    def __init__(self, start: Point, end: Point):
        if not isinstance(start, Point) or not isinstance(end, Point):
            raise TypeError("Los argumentos start y end deben ser instancias de la clase Point.")
        self.start = start
        self.end = end

    def compute_length(self):
        try:
            self.length = round(self.start.compute_distance(self.end), 2)
            return self.length
        except Exception as e:
            raise RuntimeError(f"Error al calcular la longitud de la línea: {e}")

