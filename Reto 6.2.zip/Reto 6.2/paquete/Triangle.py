from paquete.Shape import Shape
from paquete.Line import Line
from paquete.Point import Point

class Triangle(Shape):
    def __init__(self, Bottom_left_corner: Point, Bottom_right_corner: Point, Upper_corner: Point):
        if not all(isinstance(vertex, Point) for vertex in [Bottom_left_corner, Bottom_right_corner, Upper_corner]):
            raise TypeError("Todos los vértices deben ser instancias de la clase Point.")
        super().__init__()
        self.is_regular = False
        self.vertices.append(Bottom_left_corner)
        self.vertices.append(Bottom_right_corner)
        self.vertices.append(Upper_corner)
        self.edges.append(Line(Bottom_left_corner, Bottom_right_corner))
        self.edges.append(Line(Bottom_right_corner, Upper_corner))
        self.edges.append(Line(Upper_corner, Bottom_left_corner))

    def compute_perimeter(self):
        try:
            return (self.edges[0].compute_length() +
                    self.edges[1].compute_length() +
                    self.edges[2].compute_length())
        except Exception as e:
            raise RuntimeError(f"Error al calcular el perímetro del triángulo: {e}")

