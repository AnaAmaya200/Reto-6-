from paquete.Rectangle import Rectangle
from paquete.Point import Point

class Square(Rectangle):
    def __init__(self, Bottom_left_corner: Point, Upper_right_corner: Point):
        try:
            if not isinstance(Bottom_left_corner, Point) or not isinstance(Upper_right_corner, Point):
                raise TypeError("Los vértices deben ser instancias de la clase Point.")
            super().__init__(Bottom_left_corner, Upper_right_corner)
            self.is_regular = True
        except TypeError as te:
            print(f"Error de tipo: {te}")
        except Exception as e:
            print(f"Error al inicializar el cuadrado: {e}")

    def compute_area(self):
        try:
            return super().compute_area()
        except Exception as e:
            raise RuntimeError(f"Error al calcular el área del cuadrado: {e}")

    def compute_inner_angles(self):
        try:
            return super().compute_inner_angles()
        except Exception as e:
            raise RuntimeError(f"Error al calcular los ángulos internos del cuadrado: {e}")

