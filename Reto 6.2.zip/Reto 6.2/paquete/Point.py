class Point:
    def __init__(self, x=0.0, y=0.0):
        try:
            self.x = float(x)
            self.y = float(y)
        except ValueError:
            raise ValueError("Las coordenadas deben ser números.")

    def compute_distance(self, point: "Point"):
        if not isinstance(point, Point):
            raise TypeError("El argumento debe ser una instancia de la clase Point.")
        return ((self.x - point.x)**2 + (self.y - point.y)**2)**0.5

