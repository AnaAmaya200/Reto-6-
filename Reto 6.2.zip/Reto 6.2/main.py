import math
import paquete.Point as Point
import paquete.Line as Line
import paquete.Rectangle as Rectangle
import paquete.Triangle as Triangle
import paquete.RectangleTypes.Square as Square
import paquete.TriangleTypes.Equilateral as Equilateral
import paquete.TriangleTypes.Isosceles as Isosceles
import paquete.TriangleTypes.Scalene as Scalene
import paquete.TriangleTypes.Trirectangle as Trirectangle
#Point
try:
    p1 = Point(3, 4)
    p2 = Point(0, 0)
    print("Distancia:", p1.compute_distance(p2))
except ValueError as ve:
    print(f"Error de valor: {ve}")
except TypeError as te:
    print(f"Error de tipo: {te}")
#Line
try:
    p1 = Point(0, 0)
    p2 = Point(3, 4)
    linea = Line(p1, p2)
    print("Longitud de la línea:", linea.compute_length())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

#Triangle
try:
    p1 = Point(0, 0)
    p2 = Point(3, 0)
    p3 = Point(3, 4)
    triangulo = Triangle(p1, p2, p3)
    print("Perímetro del triángulo:", triangulo.compute_perimeter())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

#Rectangle
try:
    p1 = Point(0, 0)
    p2 = Point(4, 3)
    rectangulo = Rectangle(p1, p2)
    print("Área del rectángulo:", rectangulo.compute_area())
    print("Perímetro del rectángulo:", rectangulo.compute_perimeter())
    print("Ángulos internos del rectángulo:", rectangulo.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")
#Square
try:
    p1 = Point(0, 0)
    p2 = Point(4, 4)
    cuadrado = Square(p1, p2)
    print("Área del cuadrado:", cuadrado.compute_area())
    print("Ángulos internos del cuadrado:", cuadrado.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

#Equilateral
try:
    p1 = Point(0, 0)
    p2 = Point(3, 0)
    p3 = Point(1.5, 2.598)
    equilatero = Equilateral(p1, p2, p3)
    print("Área del triángulo equilátero:", equilatero.compute_area())
    print("Perímetro del triángulo equilátero:", equilatero.compute_perimeter())
    print("Ángulos internos del triángulo equilátero:", equilatero.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

# Isosceles
try:
    p1 = Point(0, 0)
    p2 = Point(3, 0)
    p3 = Point(1.5, 4)
    isosceles = Isosceles(p1, p2, p3)
    print("Área del triángulo isósceles:", isosceles.compute_area())
    print("Perímetro del triángulo isósceles:", isosceles.compute_perimeter())
    print("Ángulos internos del triángulo isósceles:", isosceles.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

# Scalene
try:
    p1 = Point(0, 0)
    p2 = Point(4, 0)
    p3 = Point(2, 3)
    escaleno = Scalene(p1, p2, p3)
    print("Área del triángulo escaleno:", escaleno.compute_area())
    print("Perímetro del triángulo escaleno:", escaleno.compute_perimeter())
    print("Ángulos internos del triángulo escaleno:", escaleno.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")

# Trirectangle
try:
    p1 = Point(0, 0)
    p2 = Point(4, 0)
    p3 = Point(4, 3)
    trirectangulo = Trirectangle(p1, p2, p3)
    print("Área del triángulo rectángulo:", trirectangulo.compute_area())
    print("Perímetro del triángulo rectángulo:", trirectangulo.compute_perimeter())
    print("Ángulos internos del triángulo rectángulo:", trirectangulo.compute_inner_angles())
except TypeError as te:
    print(f"Error de tipo: {te}")
except RuntimeError as re:
    print(f"Error de ejecución: {re}")
